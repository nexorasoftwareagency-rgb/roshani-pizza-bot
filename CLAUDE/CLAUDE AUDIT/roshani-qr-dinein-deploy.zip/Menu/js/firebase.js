/**
 * Menu/js/firebase.js
 * Public, unauthenticated Firebase client for the customer-facing menu app.
 *
 * SECURITY MODEL (see Commands & Guidance doc for the full rules JSON):
 *   - tables: read-only, world-readable (token lookup happens client-side
 *     by scanning for a matching .token field — see session.js)
 *   - tableSessions: create + limited update only (no delete from here)
 *   - orders: create-only (no update/delete from this client — staff-only)
 *   - tableRequests: create-only
 *
 * This file intentionally does NOT use Firebase Auth. Access control is
 * enforced entirely by Realtime Database Security Rules, not by a login
 * wall, since customers must never need to sign in to order food.
 */
import { initializeApp } from "https://www.gstatic.com/firebasejs/10.7.1/firebase-app.js";
import {
    getDatabase, ref, get, onValue, set, push, update, runTransaction
} from "https://www.gstatic.com/firebasejs/10.7.1/firebase-database.js";

// Paste the SAME config values used in Admin/firebase-config.js.
// This is safe to expose publicly — Firebase config is not a secret,
// access control lives in the Security Rules, not in this object.
const firebaseConfig = {
    apiKey: "YOUR_API_KEY",
    authDomain: "YOUR_PROJECT.firebaseapp.com",
    databaseURL: "https://YOUR_PROJECT-default-rtdb.firebaseio.com",
    projectId: "YOUR_PROJECT",
    storageBucket: "YOUR_PROJECT.appspot.com",
    messagingSenderId: "YOUR_SENDER_ID",
    appId: "YOUR_APP_ID"
};

export const app = initializeApp(firebaseConfig);
export const db = getDatabase(app);

// ---------------------------------------------------------------
// Outlet resolution — parsed once from the URL path, e.g.
//   https://menu.roshani.com/pizza/?t=7YH8K2P4X9F6M2A
// If your deployment serves a single outlet from a fixed subdomain,
// hardcode OUTLET instead of parsing it.
// ---------------------------------------------------------------
const pathParts = window.location.pathname.split('/').filter(Boolean);
export const OUTLET = pathParts[0] || 'pizza';

export function outletRef(path) {
    return ref(db, `${OUTLET}/${path}`);
}

export { get, onValue, set, push, update, runTransaction };
